import requests
import time
import re
import json
import warnings
import os
import sys
from datetime import datetime, timedelta
warnings.filterwarnings('ignore')

def safe_print(message):
    """Безпечно виводить повідомлення в консоль з обробкою Unicode"""
    try:
        print(message)
    except UnicodeEncodeError:
        try:
            sys.stdout.buffer.write((message + '\n').encode('utf-8'))
            sys.stdout.buffer.flush()
        except Exception:
            try:
                safe_message = message.encode('ascii', 'replace').decode('ascii')
                print(safe_message)
            except Exception:
                pass

class PurchaseBot:
    def __init__(self, email_address: str, password: str, product_id: list = None, check_interval: float = 1.0, start_time: str = None, captcha_api: str = None, captcha_solve_before_time: int = 180, log_level: str = "INFO", log_file: str = None, max_purchase_retries: int = 3):
        self.email_address = email_address
        self.password = password
        self.product_id = product_id  # Список ID товарів або None, тоді визначиться автоматично
        self.check_interval = check_interval
        self.start_time = start_time.strip() if start_time else None
        self.captcha_api = captcha_api or "CAP-8DBE9957B62A41BBDF143D5C0DFB02DDA21D137F388CF5A6965A5232CEA19D23"
        self.captcha_solve_before_time = captcha_solve_before_time  # За скільки секунд до start_time розв'язувати капчу
        self.log_level = log_level.upper()  # "INFO" або "DEBUG"
        self.max_purchase_retries = max_purchase_retries  # Максимальна кількість спроб покупки
        self.session = requests.Session()
        self.base_url = "https://coins.bank.gov.ua"
        self.cookies = {}
        self.log_file = log_file or f"purchase_bot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        # Файл для збереження повних відповідей сервера (JSON формат)
        self.responses_file = self.log_file.replace('.log', '_server_responses.json')
        self.is_running = True
        
        # Налаштування Telegram для відправки логів
        self.telegram_config = None
        self.send_logs_on_exit = False
        self.auto_delete_logs = False
        
        # Без проксі
        self.proxies = None
        
    def log(self, message, level="INFO"):
        """
        Додає повідомлення в лог з консольним стилем та зберігає в файл
        
        Рівні логування:
        - SYSTEM: Системні повідомлення (запуск, завершення)
        - INFO: Загальна інформація про процес
        - SUCCESS: Успішні операції
        - WARNING: Попередження (не критичні проблеми)
        - ERROR: Помилки
        - DEBUG: Детальна інформація для діагностики
        
        ВСІ логи виводяться в консоль та зберігаються в файл незалежно від log_level
        """
        timestamp = datetime.now().strftime("%H:%M:%S")
        
        level_prefixes = {
            "INFO": "[INFO]",
            "SUCCESS": "[OK]",
            "ERROR": "[ERROR]",
            "WARNING": "[WARN]",
            "DEBUG": "[DEBUG]",
            "SYSTEM": "[SYS]"
        }
        
        prefix = level_prefixes.get(level, "[INFO]")
        log_message = f"[{timestamp}] {prefix} {message}"
        
        # Виводимо в консоль (ВСІ логи)
        safe_print(log_message)
        
        # Зберігаємо в файл (ВСІ логи)
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(log_message + "\n")
        except Exception as e:
            # Якщо не вдалося записати в файл, виводимо помилку тільки в консоль
            safe_print(f"[ERROR] Не вдалося записати в лог-файл: {e}")
    
    def save_server_response(self, request_type: str, url: str, method: str, request_headers: dict, request_data: dict, response_status: int, response_headers: dict, response_text: str, response_json: dict = None, timestamp: str = None):
        """
        Зберігає повну відповідь сервера в JSON файл для подальшого аналізу
        
        Args:
            request_type: Тип запиту ('purchase', 'check_cart', 'login', тощо)
            url: URL запиту
            method: HTTP метод (GET, POST)
            request_headers: Заголовки запиту
            request_data: Дані запиту
            response_status: HTTP статус код
            response_headers: Заголовки відповіді
            response_text: Текст відповіді
            response_json: Розпарсений JSON (якщо є)
            timestamp: Часова мітка (якщо не вказано, використовується поточний час)
        """
        if timestamp is None:
            timestamp = datetime.now().isoformat()
        
        response_data = {
            "timestamp": timestamp,
            "request_type": request_type,
            "request": {
                "url": url,
                "method": method,
                "headers": request_headers,
                "data": request_data
            },
            "response": {
                "status_code": response_status,
                "headers": dict(response_headers) if response_headers else {},
                "text": response_text,
                "json": response_json if response_json else None
            }
        }
        
        try:
            # Завантажуємо існуючі дані (якщо файл існує)
            existing_data = []
            if os.path.exists(self.responses_file):
                try:
                    with open(self.responses_file, "r", encoding="utf-8") as f:
                        existing_data = json.load(f)
                        if not isinstance(existing_data, list):
                            existing_data = [existing_data]
                except (json.JSONDecodeError, Exception):
                    existing_data = []
            
            # Додаємо нову відповідь
            existing_data.append(response_data)
            
            # Зберігаємо оновлені дані
            with open(self.responses_file, "w", encoding="utf-8") as f:
                json.dump(existing_data, f, indent=2, ensure_ascii=False)
            
            self.log(f"Відповідь сервера збережено в файл: {self.responses_file}", "DEBUG")
        except Exception as e:
            self.log(f"Помилка збереження відповіді сервера: {e}", "WARNING")
    
    def login(self) -> dict:
        """Логін на сайт"""
        self.log("Підключення до системи...", "SYSTEM")
        
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'uk-UA,uk;q=0.9,en-US;q=0.8,en;q=0.7',
                'priority': 'u=0, i',
                'referer': 'https://coins.bank.gov.ua/',
                'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'
            }

            self.log("Отримуємо сторінку логіну...", "DEBUG")
            response = self.session.get(
                "https://coins.bank.gov.ua/login.php",
                headers=headers,
                verify=False,
                proxies=self.proxies
            )

            if response.status_code != 200:
                self.log(f"Помилка підключення: {response.status_code}", "ERROR")
                return {"status": "error", "error": f"HTTP {response.status_code}"}
            
            csrf_token = None
            csrf_patterns = [
                r'name="_csrf"\s+value="([^"]+)"',
                r'_csrf" value="([^"]+)"',
                r'name="_csrf"[^>]*value="([^"]+)"'
            ]
            
            for pattern in csrf_patterns:
                match = re.search(pattern, response.text)
                if match:
                    csrf_token = match.group(1)
                    break

            if not csrf_token:
                self.log("Помилка підключення", "ERROR")
                return {"status": "error", "error": "CSRF token not found"}

            self.log("Знайдено CSRF токен", "DEBUG")

            login_data = {
                '_csrf': csrf_token,
                'email_address': self.email_address,
                'password': self.password
            }

            login_headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Origin': 'https://coins.bank.gov.ua',
                'Referer': 'https://coins.bank.gov.ua/login.php',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
                'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"'
            }

            self.log("Надсилаємо дані логіну...", "DEBUG")
            login_response = self.session.post(
                "https://coins.bank.gov.ua/login.php?action=process",
                data=login_data,
                headers=login_headers,
                allow_redirects=True,
                verify=False,
                proxies=self.proxies
            )
            
            self.log(f"Статус відповіді: {login_response.status_code}", "DEBUG")
            self.log(f"Фінальний URL: {login_response.url}", "DEBUG")

            # Отримуємо всі cookies з CookieJar
            cookies_dict = {}
            for cookie in self.session.cookies:
                cookies_dict[cookie.name] = {
                    "value": cookie.value,
                    "domain": cookie.domain if hasattr(cookie, 'domain') else ".coins.bank.gov.ua",
                    "path": cookie.path if hasattr(cookie, 'path') and cookie.path else "/",
                    "secure": cookie.secure if hasattr(cookie, 'secure') else False,
                    "expires": int(cookie.expires) if hasattr(cookie, 'expires') and cookie.expires else 0
                }
            
            self.log(f"Отримано кукі: {len(cookies_dict)}", "DEBUG")

            user_name = None
            name_patterns = [
                r'<span class="span-name">\s*([^<]+)\s*</span>',
                r'<span>Вітаємо, </span><span class="span-name">\s*([^<]+)\s*</span>',
                r'class="span-name"[^>]*>([^<]+)</span>'
            ]
            
            for pattern in name_patterns:
                match = re.search(pattern, login_response.text)
                if match:
                    user_name = match.group(1).strip()
                    break

            if user_name:
                status = "success"
                self.log(f"Підключення успішне", "SUCCESS")
            elif "login" not in login_response.url.lower() and login_response.status_code == 200:
                status = "partial_success"
                self.log("Підключення можливо успішне", "WARNING")
            else:
                status = "error"
                self.log("Помилка підключення", "ERROR")

            result = {
                "timestamp": datetime.now().isoformat(),
                "status": status,
                "user_name": user_name,
                "final_url": login_response.url,
                "status_code": login_response.status_code,
                "cookies": cookies_dict,
            }

            if status in ["success", "partial_success"]:
                self.cookies = cookies_dict
                self.log("Куки оновлено для всієї сесії", "DEBUG")

            return result

        except Exception as e:
            self.log(f"Помилка під час логіну: {e}", "ERROR")
            return {"status": "error", "error": str(e)}
    
    def get_page(self, url, referer=None):
        """Отримує сторінку"""
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'uk-UA,uk;q=0.9,en-US;q=0.8,en;q=0.7',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
        }
        
        if referer:
            headers['referer'] = referer
        
        try:
            response = self.session.get(
                url,
                headers=headers,
                verify=False,
                proxies=self.proxies
            )
            
            if response.status_code == 200:
                return response.text
            else:
                self.log(f"Помилка отримання {url}: {response.status_code}", "ERROR")
                return None
        except Exception as e:
            self.log(f"Помилка отримання {url}: {e}", "ERROR")
            return None

    def extract_cloudflare_data(self, html):
        """Витягує дані Cloudflare зі сторінки"""
        self.log("Витягуємо дані Cloudflare...", "DEBUG")
        
        data = {}
        
        site_key_match = re.search(r'name="cloud_flare_site_key"\s+value="([^"]+)"', html)
        if site_key_match:
            data['site_key'] = site_key_match.group(1)
            self.log("Site key отримано", "DEBUG")
        else:
            self.log("Помилка обробки захисту", "ERROR")
            return None
        
        js_url_match = re.search(r'name="cloud_flare_js_url"\s+value="([^"]+)"', html)
        if js_url_match:
            data['js_url'] = js_url_match.group(1)
        else:
            data['js_url'] = "https://challenges.cloudflare.com/turnstile/v0/api.js"
        
        form_match = re.search(r'<form[^>]*action="([^"]*)"[^>]*>', html)
        if form_match:
            data['action_url'] = form_match.group(1)
            if not data['action_url'].startswith('http'):
                data['action_url'] = f"{self.base_url}/{data['action_url'].lstrip('/')}"
        else:
            data['action_url'] = f"{self.base_url}/wishlist.php"
        
        return data

    def solve_turnstile_captcha(self, site_key, page_url):
        """Розв'язує Cloudflare Turnstile капчу через Capsolver API"""
        self.log("Обробка захисту...", "DEBUG")
        
        create_url = "https://api.capsolver.com/createTask"
        create_data = {
            "clientKey": self.captcha_api,
            "task": {
                "type": "AntiTurnstileTaskProxyLess",
                "websiteURL": page_url,
                "websiteKey": site_key
            }
        }
        
        self.log("Надсилання завдання на розв'язання капчі...", "DEBUG")
        
        try:
            import requests as std_requests
            create_response = std_requests.post(create_url, json=create_data, verify=True)
            create_result = create_response.json()
            
            if create_result.get('errorId') != 0:
                error_code = create_result.get('errorCode', 'UNKNOWN')
                error_desc = create_result.get('errorDescription', 'No description')
                self.log(f"Помилка обробки захисту: {error_code}", "ERROR")
                return None
            
            task_id = create_result.get('taskId')
            if not task_id:
                self.log(f"Помилка обробки захисту", "ERROR")
                return None
                
            self.log(f"Завдання створено, ID: {task_id}", "DEBUG")
            
            get_url = "https://api.capsolver.com/getTaskResult"
            
            # Перевіряємо кожні 0.2 секунди
            for i in range(150):
                time.sleep(0.2)
                get_data = {
                    "clientKey": self.captcha_api,
                    "taskId": task_id
                }
                get_response = std_requests.post(get_url, json=get_data, verify=True)
                get_result = get_response.json()
                
                if get_result.get('status') == 'ready':
                    solution = get_result.get('solution', {})
                    token = solution.get('token')
                    if token:
                        self.log(f"Захист оброблено", "DEBUG")
                        return token
                    else:
                        self.log(f"Помилка обробки захисту", "ERROR")
                        return None
                elif get_result.get('status') == 'processing':
                    continue
                else:
                    error_code = get_result.get('errorCode', 'UNKNOWN')
                    error_desc = create_result.get('errorDescription', 'No description')
                    self.log(f"Помилка обробки захисту: {error_code}", "ERROR")
                    return None
            
            self.log("Час очікування вийшов", "ERROR")
            return None
            
        except Exception as e:
            self.log(f"Помилка обробки захисту: {e}", "ERROR")
            return None

    def submit_turnstile_form(self, turnstile_token, site_key):
        """Надсилає форму з Turnstile токеном для проходження капчі"""
        self.log("Завершення обробки захисту...", "DEBUG")
        
        url = f"{self.base_url}/"
        
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': self.base_url,
            'referer': f'{self.base_url}/wishlist.php',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
        }
        
        data = {
            'cf-turnstile-response': turnstile_token,
            'cloud_flare_site_key': site_key,
            'cloud_flare_js_url': 'https://challenges.cloudflare.com/turnstile/v0/api.js',
            'action': 'process_turnstile'
        }
        
        try:
            response = self.session.post(
                url,
                headers=headers,
                data=data,
                verify=False,
                allow_redirects=True,
                proxies=self.proxies
            )
            
            self.log(f"Статус після відправки форми: {response.status_code}", "DEBUG")
            if response.status_code == 200:
                self.log("Обробка захисту завершена", "DEBUG")
                return True
            else:
                self.log(f"Помилка обробки захисту", "ERROR")
                return False
        except Exception as e:
            self.log(f"Помилка обробки захисту", "ERROR")
            return False

    def extract_buyable_products(self, html):
        """Витягує товари з кнопкою 'Купити' або 'Видалити' зі сторінки wishlist"""
        products = []
        
        # Спочатку шукаємо товари з кнопкою "Купити"
        buy_button_pattern = r'<button[^>]*class="[^"]*add2cart[^"]*"[^>]*data-id="(\d+)"[^>]*>Купити</button>'
        matches = re.finditer(buy_button_pattern, html)
        
        for match in matches:
            product_id = match.group(1)
            
            name_pattern = rf'data-id="{product_id}"[^>]*>Купити</button>.*?<a[^>]*>([^<]+)</a>'
            name_match = re.search(name_pattern, html, re.DOTALL)
            
            product_name = "Невідома назва"
            if name_match:
                product_name = name_match.group(1).strip()
            
            products.append({
                'id': product_id,
                'name': product_name,
                'has_buy_button': True
            })
        
        # Якщо не знайдено товарів з кнопкою "Купити", шукаємо товари з кнопкою "Видалити"
        if not products:
            self.log("Товари з кнопкою 'Купити' не знайдено, шукаємо товари з кнопкою 'Видалити'...", "INFO")
            delete_button_pattern = r'wishlist\.php\?delete_prod=(\d+)'
            matches = re.finditer(delete_button_pattern, html)
            
            for match in matches:
                product_id = match.group(1)
                
                # Шукаємо назву товару поблизу кнопки "Видалити"
                # Назва товару зазвичай в попередніх рядках таблиці
                name_pattern = rf'delete_prod={product_id}[^>]*>Видалити</a>.*?<a[^>]*href="[^"]*p-{product_id}[^"]*"[^>]*>([^<]+)</a>'
                name_match = re.search(name_pattern, html, re.DOTALL)
                
                if not name_match:
                    # Альтернативний патерн - шукаємо назву в попередніх рядках
                    name_pattern = rf'<a[^>]*href="[^"]*p-{product_id}[^"]*"[^>]*>([^<]+)</a>'
                    name_match = re.search(name_pattern, html)
                
                product_name = "Невідома назва"
                if name_match:
                    product_name = name_match.group(1).strip()
                
                products.append({
                    'id': product_id,
                    'name': product_name,
                    'has_buy_button': False
                })
        
        return products

    def get_wishlist_products(self):
        """Отримує список товарів з wishlist"""
        self.log("Перевірка доступності товарів...", "DEBUG")
        html = self.get_page(f"{self.base_url}/wishlist.php")
        if not html:
            return None
        
        products = self.extract_buyable_products(html)
        return products

    def prepare_purchase_data(self):
        """
        Підготовка даних для покупки: отримує сторінку, розв'язує капчу, збирає CSRF токен

        Це виконується один раз на початку для підготовки всіх необхідних даних
        """
        self.log("Збір інформації для покупки...", "SYSTEM")

        # Отримуємо сторінку wishlist
        self.log("Отримання сторінки wishlist...", "DEBUG")
        html = self.get_page(f"{self.base_url}/wishlist.php")
        if not html:
            self.log("Помилка отримання даних", "ERROR")
            return None

        # Створюємо словник для зберігання токенів для кожного товару
        product_tokens = {}
        
        # Перевіряємо чи є Cloudflare challenge
        if 'cloud_flare_site_key' in html:
            self.log("Обробка захисту...", "INFO")

            # Витягуємо дані Cloudflare
            cf_data = self.extract_cloudflare_data(html)
            if not cf_data:
                self.log("Помилка обробки захисту", "ERROR")
                return None

            # Генеруємо токени для кожного товару (максимум 3)
            max_products = min(3, len(self.product_id) if self.product_id else 3)
            self.log(f"Генерація {max_products} токенів для паралельних покупок...", "INFO")
            
            for i in range(max_products):
                self.log(f"Генерація токену #{i+1}...", "DEBUG")
                
                # Розв'язуємо капчу з повторними спробами
                max_attempts = 10  # Максимум спроб
                attempt = 0
                turnstile_token = None

                while attempt < max_attempts and not turnstile_token:
                    attempt += 1
                    if attempt > 1:
                        self.log(f"Повторна спроба обробки захисту ({attempt}/{max_attempts})...", "INFO")
                    else:
                        self.log("Обробка захисту...", "INFO")

                    turnstile_token = self.solve_turnstile_captcha(
                        site_key=cf_data['site_key'],
                        page_url=f"{self.base_url}/wishlist.php"
                    )

                    if not turnstile_token:
                        if attempt < max_attempts:
                            wait_time = min(5 * attempt, 30)  # Збільшуємо затримку з кожною спробою (макс 30 сек)
                            self.log(f"Очікування {wait_time} секунд перед наступною спробою...", "WARNING")
                            time.sleep(wait_time)

                            # Оновлюємо сторінку та дані Cloudflare перед наступною спробою
                            self.log("Оновлення сторінки перед наступною спробою...", "DEBUG")
                            html = self.get_page(f"{self.base_url}/wishlist.php")
                            if html and 'cloud_flare_site_key' in html:
                                cf_data = self.extract_cloudflare_data(html)
                                if not cf_data:
                                    self.log("Не вдалося витягти дані Cloudflare після оновлення", "WARNING")
                        else:
                            self.log(f"Всі {max_attempts} спроби обробки захисту не вдалися", "ERROR")
                            return None

                if not turnstile_token:
                    self.log("Помилка обробки захисту", "ERROR")
                    return None

                self.log(f"Захист успішно оброблено для токену #{i+1}", "SUCCESS")

                # Відправляємо форму з Turnstile токеном
                success = self.submit_turnstile_form(turnstile_token, cf_data['site_key'])
                if not success:
                    self.log("Помилка обробки захисту", "ERROR")
                    return None

                # Зберігаємо токен для цього "товару" (індекс)
                product_tokens[i] = turnstile_token

            # Отримуємо сторінку після проходження капчі
            self.log("Отримання сторінки після проходження капчі...", "DEBUG")
            html = self.get_page(f"{self.base_url}/wishlist.php")
            if not html:
                self.log("Помилка отримання даних", "ERROR")
                return None

        # Використовуємо перший Turnstile токен як основний CSRF токен (для сумісності)
        # Якщо капчі не було, turnstile_token буде None, тоді спробуємо знайти токен на сторінці
        csrf_token = None
        if product_tokens:
            # Використовуємо перший токен як основний
            csrf_token = list(product_tokens.values())[0]
        else:
            # Якщо немає згенерованих токенів, шукаємо токен на сторінці
            self.log("Отримання CSRF токену зі сторінки...", "DEBUG")
            csrf_patterns = [
                r'name="token"\s+value="([^"]+)"',
                r'token["\']?\s*[:=]\s*["\']([^"\']+)["\']',
                r'data-token=["\']([^"\']+)["\']',
                r'name="_csrf"\s+value="([^"]+)"',
                r'_csrf" value="([^"]+)"'
            ]

            for pattern in csrf_patterns:
                match = re.search(pattern, html)
                if match:
                    csrf_token = match.group(1)
                    break

            if not csrf_token:
                # Спробуємо знайти токен в JavaScript
                js_token_match = re.search(r'token["\']?\s*[:=]\s*["\']([^"\']+)["\']', html)
                if js_token_match:
                    csrf_token = js_token_match.group(1)

        if not csrf_token:
            self.log("Помилка збору даних", "ERROR")
            return None

        self.log(f"Основний CSRF токен отримано: {csrf_token[:20]}...", "DEBUG")

        purchase_data = {
            "csrf_token": csrf_token,
            "product_tokens": product_tokens,  # Токени для кожного товару
            "turnstile_token": csrf_token,  # Зберігаємо для сумісності
            "html": html
        }

        self.log("Інформація для покупки зібрана", "SUCCESS")
        return purchase_data

    def _parse_start_time(self, time_str):
        """Парсить час у форматі hh:mm:ss та повертає datetime об'єкт"""
        try:
            if not time_str or not time_str.strip():
                return None
            
            parts = time_str.strip().split(':')
            if len(parts) != 3:
                self.log(f"Невірний формат часу: {time_str}. Очікується hh:mm:ss", "ERROR")
                return None
            
            hour = int(parts[0])
            minute = int(parts[1])
            second = int(parts[2])
            
            if not (0 <= hour <= 23 and 0 <= minute <= 59 and 0 <= second <= 59):
                self.log(f"Невірні значення часу: {time_str}. Години: 0-23, хвилини/секунди: 0-59", "ERROR")
                return None
            
            now = datetime.now()
            target_time = now.replace(hour=hour, minute=minute, second=second, microsecond=0)
            
            # Якщо вказаний час вже минув сьогодні, встановлюємо на завтра
            if target_time <= now:
                target_time += timedelta(days=1)
                self.log(f"Вказаний час вже минув сьогодні. Встановлюємо на завтра: {target_time.strftime('%Y-%m-%d %H:%M:%S')}", "INFO")
            
            return target_time
        except (ValueError, IndexError) as e:
            self.log(f"Помилка парсингу часу '{time_str}': {e}", "ERROR")
            return None
    
    def _wait_until_start_time(self, target_time):
        """Чекає до вказаного часу початку моніторингу"""
        last_log_time = 0
        while self.is_running:
            now = datetime.now()
            if now >= target_time:
                return True
            
            time_diff = (target_time - now).total_seconds()
            hours = int(time_diff // 3600)
            minutes = int((time_diff % 3600) // 60)
            seconds = int(time_diff % 60)
            
            # Показуємо оновлення кожні 5 секунд або якщо залишилось менше 10 секунд
            current_second = int(time_diff)
            if current_second != last_log_time and (current_second % 5 == 0 or time_diff < 10):
                self.log(f"Очікування до {target_time.strftime('%H:%M:%S')}. Залишилось: {hours:02d}:{minutes:02d}:{seconds:02d}", "INFO")
                last_log_time = current_second
            
            # Затримка з перевіркою is_running
            elapsed = 0
            while elapsed < 1.0 and self.is_running:
                time.sleep(0.1)
                elapsed += 0.1
        
        return False

    def execute_purchase(self, product_id, csrf_token):
        """Відправляє запит на покупку товару"""
        self.log("=" * 60, "SYSTEM")
        self.log("ВІДПРАВКА ЗАПИТУ НА ПОКУПКУ", "SYSTEM")
        self.log("=" * 60, "SYSTEM")
        
        url = f"{self.base_url}/?action=add_product&cid=249499"
        
        headers = {
            'accept': 'application/json, text/javascript, */*; q=0.01',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': self.base_url,
            'referer': f'{self.base_url}/wishlist.php',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }
        
        data = {
            'products_id': str(product_id),
            'cart_quantity': '1',
            'token': csrf_token
        }
        
        # Детальні логи перед відправкою
        self.log(f"URL: {url}", "INFO")
        self.log(f"Product ID: {product_id}", "INFO")
        self.log(f"CSRF Token: {csrf_token[:30]}...", "INFO")
        self.log(f"Headers: {json.dumps(headers, indent=2, ensure_ascii=False)}", "DEBUG")
        self.log(f"Data: {json.dumps(data, indent=2, ensure_ascii=False)}", "INFO")
        self.log("Надсилання AJAX запиту на додавання до кошика...", "INFO")
        
        try:
            response = self.session.post(
                url, 
                headers=headers, 
                data=data,
                verify=False,
                proxies=self.proxies
            )
            
            self.log("=" * 60, "SYSTEM")
            self.log("ОТРИМАНО ВІДПОВІДЬ ВІД СЕРВЕРА", "SYSTEM")
            self.log("=" * 60, "SYSTEM")
            self.log(f"HTTP Status Code: {response.status_code}", "INFO")
            self.log(f"Response Headers: {dict(response.headers)}", "DEBUG")
            self.log(f"Response URL: {response.url}", "DEBUG")
            self.log(f"Response Text (повна відповідь): {response.text}", "INFO")
            
            # Парсимо JSON якщо можливо
            response_json = None
            if response.status_code == 200:
                try:
                    response_json = response.json()
                except json.JSONDecodeError:
                    pass
            
            # Зберігаємо повну відповідь сервера в файл
            self.save_server_response(
                request_type="purchase",
                url=url,
                method="POST",
                request_headers=headers,
                request_data=data,
                response_status=response.status_code,
                response_headers=response.headers,
                response_text=response.text,
                response_json=response_json
            )
            
            if response.status_code == 200:
                try:
                    result = response_json if response_json else response.json()
                    self.log(f"Response JSON (розпарсено): {json.dumps(result, indent=2, ensure_ascii=False)}", "INFO")
                    success = result.get('success', False)
                    
                    # Додаткова інформація з відповіді
                    if 'message' in result:
                        self.log(f"Повідомлення від сервера: {result['message']}", "INFO")
                    if 'error' in result:
                        self.log(f"Помилка від сервера: {result['error']}", "ERROR")
                    if 'data' in result:
                        self.log(f"Дані від сервера: {result['data']}", "DEBUG")
                    
                    if success:
                        self.log("=" * 60, "SYSTEM")
                        self.log("ПОКУПКА УСПІШНО ВИКОНАНА!", "SUCCESS")
                        self.log("=" * 60, "SYSTEM")
                        
                        # Перевіряємо кошик після успішної покупки
                        self.log("Перевірка кошика після покупки...", "INFO")
                        cart_check = self.check_cart_status(product_id, csrf_token)
                        if cart_check:
                            self.log("Товар підтверджено в кошику!", "SUCCESS")
                        else:
                            self.log("Увага: не вдалося підтвердити товар в кошику", "WARNING")
                        
                        return True
                    else:
                        self.log("Сервер повернув success=False", "ERROR")
                        return False
                except json.JSONDecodeError as e:
                    self.log(f"Помилка парсингу JSON: {e}", "WARNING")
                    self.log(f"Спробуємо перевірити текст відповіді...", "INFO")
                    
                    # Перевіряємо текст відповіді
                    response_lower = response.text.lower()
                    if 'успішно' in response_lower or 'success' in response_lower:
                        self.log("=" * 60, "SYSTEM")
                        self.log("ПОКУПКА УСПІШНО ВИКОНАНА! (визначено за текстом)", "SUCCESS")
                        self.log("=" * 60, "SYSTEM")
                        
                        # Перевіряємо кошик
                        self.log("Перевірка кошика після покупки...", "INFO")
                        cart_check = self.check_cart_status(product_id, csrf_token)
                        if cart_check:
                            self.log("Товар підтверджено в кошику!", "SUCCESS")
                        else:
                            self.log("Увага: не вдалося підтвердити товар в кошику", "WARNING")
                        
                        return True
                    else:
                        self.log("Відповідь не містить ознак успіху", "WARNING")
                        return False
            else:
                self.log(f"Помилка HTTP запиту: {response.status_code}", "ERROR")
                self.log(f"Текст помилки: {response.text[:500]}", "ERROR")
                return False
        except Exception as e:
            self.log(f"Помилка під час покупки: {type(e).__name__}: {str(e)}", "ERROR")
            import traceback
            self.log(f"Traceback: {traceback.format_exc()}", "DEBUG")
            return False

    def execute_purchase_with_retry(self, product_id, csrf_token):
        """
        Відправляє запит на покупку з повторними спробами у разі невдачі
        
        Повторює спробу якщо:
        - Запит не надіслався (exception)
        - HTTP статус не 200
        - Сервер повернув success=False
        """
        self.log("=" * 60, "SYSTEM")
        self.log(f"СПРОБА ПОКУПКИ (максимум {self.max_purchase_retries} спроб)", "SYSTEM")
        self.log("=" * 60, "SYSTEM")
        
        for attempt in range(1, self.max_purchase_retries + 1):
            if attempt > 1:
                self.log("=" * 60, "SYSTEM")
                self.log(f"ПОВТОРНА СПРОБА ПОКУПКИ ({attempt}/{self.max_purchase_retries})", "WARNING")
                self.log("=" * 60, "SYSTEM")
                # Затримка перед повторною спробою (збільшується з кожною спробою)
                wait_time = min(2 * attempt, 10)  # 2, 4, 6... секунд (макс 10)
                self.log(f"Очікування {wait_time} секунд перед повторною спробою...", "INFO")
                time.sleep(wait_time)
            
            self.log(f"Спроба #{attempt} з {self.max_purchase_retries}", "INFO")
            
            try:
                success = self.execute_purchase(product_id, csrf_token)
                
                if success:
                    self.log(f"Покупка успішна на спробі #{attempt}!", "SUCCESS")
                    return True
                else:
                    self.log(f"Покупка не вдалася на спробі #{attempt}", "WARNING")
                    if attempt < self.max_purchase_retries:
                        self.log("Буде виконано повторну спробу...", "INFO")
                    else:
                        self.log(f"Всі {self.max_purchase_retries} спроби покупки не вдалися", "ERROR")
                        return False
                        
            except Exception as e:
                self.log(f"Виняток під час спроби #{attempt}: {type(e).__name__}: {str(e)}", "ERROR")
                if attempt < self.max_purchase_retries:
                    self.log("Буде виконано повторну спробу...", "INFO")
                else:
                    self.log(f"Всі {self.max_purchase_retries} спроби покупки не вдалися через винятки", "ERROR")
                    import traceback
                    self.log(f"Останній traceback: {traceback.format_exc()}", "DEBUG")
                    return False
        
        return False

    def check_cart_status(self, product_id, csrf_token):
        """Перевіряє статус кошика після покупки"""
        self.log("=" * 60, "SYSTEM")
        self.log("ПЕРЕВІРКА СТАТУСУ КОШИКА", "SYSTEM")
        self.log("=" * 60, "SYSTEM")
        
        url = f"{self.base_url}/product_info.php?action=check_cart_status&cid=249499"
        
        headers = {
            'accept': 'application/json, text/javascript, */*; q=0.01',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': self.base_url,
            'referer': f'{self.base_url}/wishlist.php',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }
        
        data = {
            'products_id': str(product_id),
            'cart_quantity': '1',
            'token': csrf_token
        }
        
        self.log(f"URL перевірки: {url}", "INFO")
        self.log(f"Product ID: {product_id}", "INFO")
        self.log(f"Data: {json.dumps(data, indent=2, ensure_ascii=False)}", "DEBUG")
        
        try:
            response = self.session.post(
                url, 
                headers=headers, 
                data=data,
                verify=False,
                proxies=self.proxies
            )
            
            self.log(f"HTTP Status Code: {response.status_code}", "INFO")
            self.log(f"Response Text (повна відповідь): {response.text}", "INFO")
            
            # Парсимо JSON якщо можливо
            response_json = None
            if response.status_code == 200:
                try:
                    response_json = response.json()
                except json.JSONDecodeError:
                    pass
            
            # Зберігаємо повну відповідь сервера в файл
            self.save_server_response(
                request_type="check_cart",
                url=url,
                method="POST",
                request_headers=headers,
                request_data=data,
                response_status=response.status_code,
                response_headers=response.headers,
                response_text=response.text,
                response_json=response_json
            )
            
            if response.status_code == 200:
                try:
                    result = response_json if response_json else response.json()
                    self.log(f"Response JSON: {json.dumps(result, indent=2, ensure_ascii=False)}", "INFO")
                    
                    # Перевіряємо чи товар дійсно в кошику
                    if 'success' in result and result.get('success'):
                        self.log("Товар підтверджено в кошику через check_cart_status!", "SUCCESS")
                        return True
                    elif 'in_cart' in result and result.get('in_cart'):
                        self.log("Товар знайдено в кошику!", "SUCCESS")
                        return True
                    else:
                        self.log("Товар не знайдено в кошику або статус невідомий", "WARNING")
                        return False
                except json.JSONDecodeError:
                    # Якщо не JSON, перевіряємо текст
                    if 'успішно' in response.text.lower() or 'success' in response.text.lower() or 'кошик' in response.text.lower():
                        self.log("Товар можливо в кошику (визначено за текстом)", "INFO")
                        return True
                    self.log("Не вдалося розпарсити відповідь перевірки кошика", "WARNING")
                    return False
            else:
                self.log(f"Помилка перевірки кошика: HTTP {response.status_code}", "ERROR")
                return False
        except Exception as e:
            self.log(f"Помилка перевірки кошика: {type(e).__name__}: {str(e)}", "ERROR")
            import traceback
            self.log(f"Traceback: {traceback.format_exc()}", "DEBUG")
            return False

    def run(self):
        """
        Основна функція запуску бота
        
        Логіка роботи:
        1. Виконує логін
        2. Перший прохід: заходить на wishlist, збирає дані для капчі та CSRF токен (ДО часу початку)
        3. Визначає product_id автоматично (якщо не вказано в конфігу)
        4. Очікує до часу початку моніторингу (якщо вказано)
        5. Моніторить wishlist з заданим інтервалом
        6. Коли з'являється кнопка "Купити" - відразу відправляє запит на покупку
        """
        self.log("=" * 60, "SYSTEM")
        self.log("Запуск бота для автоматичної покупки", "SYSTEM")
        self.log(f"Аккаунт: {self.email_address}", "INFO")
        self.log(f"Інтервал перевірки: {self.check_interval} секунд", "INFO")
        if self.start_time:
            self.log(f"Час початку моніторингу: {self.start_time}", "INFO")
            self.log(f"інформація буде зібрана за {self.captcha_solve_before_time} секунд до часу старту", "INFO")
        else:
            self.log("Моніторинг почнеться одразу після підготовки даних", "INFO")
        self.log(f"Лог-файл: {self.log_file}", "INFO")
        self.log(f"Файл відповідей сервера: {self.responses_file}", "INFO")
        self.log("=" * 60, "SYSTEM")
        
        # Виконуємо логін
        login_result = self.login()
        if login_result.get("status") != "success":
            self.log("Помилка логіну. Неможливо продовжити.", "ERROR")
            return False
        
        self.log("Підключення успішне", "SUCCESS")
        
        # Зберігаємо початковий target_time ДО збору інформації
        target_time = None
        if self.start_time:
            target_time = self._parse_start_time(self.start_time)
            if not target_time:
                self.log("Невірний формат часу початку моніторингу", "ERROR")
                return False
            
            # Час підготовки даних = start_time - captcha_solve_before_time
            prepare_time = target_time - timedelta(seconds=self.captcha_solve_before_time)
            now = datetime.now()
            
            # Якщо час підготовки вже минув (або дуже близько - менше 5 секунд), одразу починаємо збір
            time_to_prepare = (prepare_time - now).total_seconds()
            if time_to_prepare > 5:
                # Чекаємо до часу підготовки даних
                self.log("=" * 60, "SYSTEM")
                self.log(f"ОЧІКУВАННЯ ДО ЧАСУ ПІДГОТОВКИ: {prepare_time.strftime('%Y-%m-%d %H:%M:%S')}", "SYSTEM")
                self.log("=" * 60, "SYSTEM")
                self._wait_until_start_time(prepare_time)
                self.log("=" * 60, "SYSTEM")
                self.log("ЧАС ПІДГОТОВКИ НАСТАВ!", "SUCCESS")
                self.log("=" * 60, "SYSTEM")
            elif time_to_prepare > 0:
                # Якщо залишилось менше 5 секунд - одразу починаємо (не чекаємо)
                self.log(f"Час підготовки дуже близько ({int(time_to_prepare)} сек). Починаємо збір інформації одразу.", "INFO")
            else:
                # Час підготовки вже минув - одразу починаємо
                self.log("Час підготовки вже минув. Починаємо збір інформації одразу.", "INFO")
        
        # Підготовка даних для покупки
        self.log("=" * 60, "SYSTEM")
        self.log("ЗБІР ІНФОРМАЦІЇ ДЛЯ ПОКУПКИ", "SYSTEM")
        self.log("=" * 60, "SYSTEM")
        
        purchase_data = self.prepare_purchase_data()
        if not purchase_data:
            self.log("Помилка збору інформації", "ERROR")
            return False

        csrf_token = purchase_data.get("csrf_token")
        product_tokens = purchase_data.get("product_tokens", {})
        html = purchase_data.get("html", "")
        
        # Визначаємо product_id автоматично, якщо не вказано
        if not self.product_id:
            self.log("Визначення product_id автоматично з wishlist...", "INFO")
            products = self.extract_buyable_products(html)
            if products:
                # Беремо перші товари (може бути з кнопкою "Купити" або "Видалити")
                product_ids = []
                for i, product in enumerate(products):
                    if i >= 3:  # Максимум 3 товари
                        break
                    product_ids.append(int(product['id']))
                    has_buy = product.get('has_buy_button', True)
                    if has_buy:
                        self.log(f"Знайдено товар з кнопкою 'Купити': {product['name']} (ID: {product['id']})", "SUCCESS")
                    else:
                        self.log(f"Знайдено товар з кнопкою 'Видалити': {product['name']} (ID: {product['id']})", "INFO")
                        self.log("Будемо моніторити появлення кнопки 'Купити' для цього товару...", "INFO")
                self.product_id = product_ids
            else:
                self.log("Товари в wishlist не знайдено", "WARNING")
                self.log("Будемо моніторити появлення товарів...", "INFO")
        else:
            self.log(f"Використовується product_id з конфігу: {self.product_id}", "INFO")
        
        if not self.product_id:
            self.log("Неможливо продовжити без товару", "ERROR")
            return False
        
        self.log("Інформація зібрана", "SUCCESS")
        
        # Перевіряємо чи вказано час початку моніторингу
        # ВАЖЛИВО: Використовуємо ЗБЕРЕЖЕНИЙ target_time, не парсимо знову!
        # Якщо час вже настав (або навіть трохи минув) після збору інформації - одразу починаємо!
        if target_time:
            now = datetime.now()
            
            # Якщо час старту вже настав (або навіть трохи минув) - одразу починаємо моніторинг
            # Не чекаємо до завтра, бо інформація вже готова і можна втратити товар!
            if now >= target_time:
                self.log("=" * 60, "SYSTEM")
                self.log("ЧАС СТАРТУ ВЖЕ НАСТАВ (або трохи минув)!", "SUCCESS")
                self.log("Починаємо моніторинг ОДРАЗУ - інформація вже готова!", "SUCCESS")
                self.log("=" * 60, "SYSTEM")
            elif target_time > now:
                # Якщо час старту ще не настав, чекаємо
                time_diff = (target_time - now).total_seconds()
                self.log("=" * 60, "SYSTEM")
                self.log(f"ОЧІКУВАННЯ ДО ЧАСУ СТАРТУ: {target_time.strftime('%Y-%m-%d %H:%M:%S')}", "SYSTEM")
                self.log(f"Залишилось: {int(time_diff // 3600):02d}:{int((time_diff % 3600) // 60):02d}:{int(time_diff % 60):02d}", "INFO")
                self.log("=" * 60, "SYSTEM")
                self._wait_until_start_time(target_time)
                self.log("=" * 60, "SYSTEM")
                self.log("ЧАС СТАРТУ НАСТАВ!", "SUCCESS")
                self.log("=" * 60, "SYSTEM")
        else:
            self.log("Починаємо моніторинг одразу (start_time не вказано)", "INFO")
        
        # Моніторинг wishlist
        self.log("=" * 60, "SYSTEM")
        self.log("МОНІТОРИНГ", "SYSTEM")
        self.log(f"Інтервал перевірки: {self.check_interval} секунд", "INFO")
        self.log("Готово до покупки", "SUCCESS")
        self.log("=" * 60, "SYSTEM")
        
        check_count = 0
        while self.is_running:
            check_count += 1
            self.log(f"Перевірка #{check_count}...", "INFO")
            
            # Отримуємо список товарів з wishlist
            products = self.get_wishlist_products()
            
            if products is None:
                self.log("Помилка перевірки, повтор через інтервал", "WARNING")
                time.sleep(self.check_interval)
                continue
            
            # Перевіряємо чи є наші товари з кнопкою "Купити"
            found_products = []
            for product in products:
                product_id = int(product['id'])
                if product_id in self.product_id:
                    # Перевіряємо чи є кнопка "Купити" (has_buy_button може бути False якщо знайдено тільки кнопку "Видалити")
                    if product.get('has_buy_button', True):
                        found_products.append(product)
            
            if found_products:
                self.log("=" * 60, "SYSTEM")
                self.log(f"ТОВАРИ ДОСТУПНІ ДЛЯ ПОКУПКИ! Кількість: {len(found_products)}", "SUCCESS")
                self.log("Відправка запитів на покупку...", "SYSTEM")
                self.log("=" * 60, "SYSTEM")
                
                # Використовуємо підготовлений CSRF токен (Turnstile токен)
                # В робочій версії використовується саме Turnstile токен як CSRF токен
                self.log(f"Використовуємо підготовлений токен...", "DEBUG")
                
                # Імпортуємо threading для паралельних покупок
                import threading
                
                # Створюємо список для зберігання результатів покупок
                purchase_results = []
                purchase_lock = threading.Lock()
                
                # Функція для виконання покупки в окремому потоці
                def purchase_item(product, token_index):
                    product_id = int(product['id'])
                    # Використовуємо специфічний токен для цього товару, якщо він доступний
                    token_to_use = product_tokens.get(token_index, csrf_token)
                    self.log(f"Початок покупки товару {product['name']} (ID: {product_id}) з токеном #{token_index}", "INFO")
                    success = self.execute_purchase_with_retry(product_id, token_to_use)
                    with purchase_lock:
                        purchase_results.append((product_id, success))
                    self.log(f"Завершено покупку товару {product['name']} (ID: {product_id}), успіх: {success}", "INFO")
                
                # Створюємо та запускаємо потоки для кожної покупки
                threads = []
                for i, product in enumerate(found_products):
                    thread = threading.Thread(target=purchase_item, args=(product, i))
                    threads.append(thread)
                    thread.start()
                
                # Чекаємо завершення всіх потоків
                for thread in threads:
                    thread.join()
                
                # Перевіряємо результати покупок
                success_count = sum(1 for _, success in purchase_results if success)
                self.log(f"Результати покупок: успішно {success_count} з {len(purchase_results)}", "INFO")
                
                if success_count > 0:
                    self.log("Бот успішно завершив роботу!", "SUCCESS")
                    return True
                else:
                    self.log("Помилка при покупках, продовжуємо моніторинг...", "WARNING")
            else:
                # Перевіряємо чи товари взагалі є в wishlist (навіть без кнопки "Купити")
                products_in_wishlist = [p for p in products if int(p['id']) in self.product_id]
                if products_in_wishlist:
                    product_names = [p['name'] for p in products_in_wishlist]
                    self.log(f"Товари знайдено, очікування доступності: {', '.join(product_names)}", "INFO")
                else:
                    self.log(f"Товари не знайдено", "INFO")
            
            # Чекаємо перед наступною перевіркою
            time.sleep(self.check_interval)
        
        self.log("Моніторинг зупинено", "SYSTEM")
        
        # Відправляємо логи в Telegram при завершенні (якщо налаштовано)
        if self.send_logs_on_exit:
            self.send_logs_to_telegram()
        
        return False
    
    def set_telegram_config(self, telegram_config):
        """
        Встановлює конфігурацію Telegram для відправки логів
        
        Args:
            telegram_config: Словник з налаштуваннями Telegram
                - bot_token: Токен бота
                - chat_id: ID чату
                - send_logs_on_exit: Чи відправляти логи при завершенні
                - auto_delete_after_send: Чи видаляти логи після відправки
        """
        if telegram_config and telegram_config.get("bot_token") and telegram_config.get("chat_id"):
            self.telegram_config = telegram_config
            self.send_logs_on_exit = telegram_config.get("send_logs_on_exit", False)
            self.auto_delete_logs = telegram_config.get("auto_delete_after_send", False)
    
    def send_logs_to_telegram(self):
        """
        Відправляє логи в Telegram та очищає їх після відправки
        Використовує окремий модуль send_logs_to_telegram
        Без логування в файл (тихо)
        """
        if not self.telegram_config:
            return False
        
        try:
            # Імпортуємо модуль для відправки логів
            from send_logs_to_telegram import send_logs_to_telegram
            
            # Формуємо список файлів для відправки
            log_files = []
            if os.path.exists(self.log_file):
                log_files.append(self.log_file)
            if os.path.exists(self.responses_file):
                log_files.append(self.responses_file)
            
            if not log_files:
                return False
            
            # Відправляємо логи (без логування в файл)
            success = send_logs_to_telegram(
                log_files=log_files,
                telegram_config=self.telegram_config,  # Передаємо конфігурацію напряму
                auto_delete=self.auto_delete_logs
            )
            
            return success
        except (ImportError, Exception):
            # Тихо ігноруємо помилки
            return False
