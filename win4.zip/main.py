#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NBU Coins Purchase Bot v3
Автоматична покупка монет при появі кнопки "Купити" без UI
"""

import json
import os
import sys
from coins_bot import PurchaseBot

def load_config(config_path="config.json"):
    """Завантажує конфігурацію з файлу"""
    if not os.path.exists(config_path):
        print(f"[ERROR] Файл конфігурації {config_path} не знайдено!")
        print(f"[INFO] Створіть файл {config_path} на основі прикладу.")
        sys.exit(1)
    
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
        return config
    except json.JSONDecodeError as e:
        print(f"[ERROR] Помилка парсингу JSON у файлі {config_path}: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"[ERROR] Помилка читання файлу {config_path}: {e}")
        sys.exit(1)

def validate_config(config):
    """Перевіряє валідність конфігурації"""
    errors = []
    
    # Перевірка аккаунту
    if "account" not in config:
        errors.append("Відсутній розділ 'account' в конфігурації")
    else:
        account = config["account"]
        if "email" not in account or not account["email"]:
            errors.append("Відсутнє або порожнє поле 'email' в розділі 'account'")
        if "password" not in account or not account["password"]:
            errors.append("Відсутнє або порожнє поле 'password' в розділі 'account'")
    
    # Перевірка покупки
    if "purchase" not in config:
        errors.append("Відсутній розділ 'purchase' в конфігурації")
    else:
        purchase = config["purchase"]
        # product_id тепер опціональний
        if "check_interval" in purchase:
            try:
                interval = float(purchase["check_interval"])
                if interval <= 0:
                    errors.append("check_interval повинен бути більше 0")
            except (ValueError, TypeError):
                errors.append("check_interval повинен бути числом")
        
        # Перевірка product_id - тепер це список (може бути пустим або містити до 2 елементів)
        if "product_id" in purchase:
            product_id = purchase["product_id"]
            if product_id is not None:
                # Якщо це список, перевіряємо його
                if isinstance(product_id, list):
                    if len(product_id) > 3:
                        errors.append("Максимальна кількість товарів для покупки - 3")
                    else:
                        # Перевіряємо кожен елемент списку
                        for i, pid in enumerate(product_id):
                            if pid is not None:
                                try:
                                    int(pid)
                                except (ValueError, TypeError):
                                    errors.append(f"product_id[{i}] повинен бути числом або null")
                else:
                    # Якщо це не список, це помилка
                    errors.append("product_id повинен бути списком (масивом)")
        
        # Перевірка формату start_time якщо вказано
        if "start_time" in purchase and purchase["start_time"]:
            time_str = str(purchase["start_time"]).strip()
            if time_str.lower() != "null":
                try:
                    parts = time_str.split(":")
                    if len(parts) != 3:
                        errors.append(f"Невірний формат start_time '{time_str}'. Очікується hh:mm:ss")
                    else:
                        hour, minute, second = int(parts[0]), int(parts[1]), int(parts[2])
                        if not (0 <= hour <= 23 and 0 <= minute <= 59 and 0 <= second <= 59):
                            errors.append(f"Невірні значення start_time '{time_str}'. Години: 0-23, хвилини/секунди: 0-59")
                except ValueError:
                    errors.append(f"Невірний формат start_time '{time_str}'. Очікується hh:mm:ss")
    
    # Перевірка settings
    if "settings" in config:
        settings = config["settings"]
        if "check_interval" in settings:
            try:
                interval = float(settings["check_interval"])
                if interval <= 0:
                    errors.append("settings.check_interval повинен бути більше 0")
            except (ValueError, TypeError):
                errors.append("settings.check_interval повинен бути числом")
    
    if errors:
        print("[ERROR] Помилки в конфігурації:")
        for error in errors:
            print(f"  - {error}")
        sys.exit(1)
    
    return True

def main():
    """Головна функція"""
    print("=" * 60)
    print("NBU Coins Purchase Bot v3")
    print("Автоматична покупка монет при появі кнопки 'Купити'")
    print("=" * 60)
    print()
    
    # Завантажуємо конфігурацію
    config = load_config()
    
    # Перевіряємо валідність
    validate_config(config)
    
    # Витягуємо дані з конфігурації
    account = config["account"]
    purchase = config["purchase"]
    captcha = config.get("captcha", {})
    settings = config.get("settings", {})
    
    email = account["email"]
    password = account["password"]
    
    # product_id може бути None, одним ID або списком ID - тоді визначиться автоматично
    product_id = purchase.get("product_id")
    if product_id is not None:
        # Якщо це список, перевіряємо його
        if isinstance(product_id, list):
            # Перетворюємо всі елементи в int, ігноруючи None
            processed_ids = []
            for pid in product_id:
                if pid is not None:
                    try:
                        processed_ids.append(int(pid))
                    except (ValueError, TypeError):
                        pass
            product_id = processed_ids if processed_ids else None
        else:
            # Якщо це один елемент, перетворюємо в список
            try:
                product_id = [int(product_id)]
            except (ValueError, TypeError):
                product_id = None
    
    # check_interval з purchase або settings
    check_interval = purchase.get("check_interval") or settings.get("check_interval", 1.0)
    try:
        check_interval = float(check_interval)
    except (ValueError, TypeError):
        check_interval = 1.0
    
    # start_time - час початку моніторингу (опціонально)
    start_time = purchase.get("start_time")
    if start_time:
        start_time = str(start_time).strip()
        if not start_time or start_time.lower() == "null":
            start_time = None
    
    captcha_api = captcha.get("api_key")
    captcha_solve_before_time = captcha.get("solve_before_time", 180)  # За замовчуванням 180 секунд (3 хвилини)
    try:
        captcha_solve_before_time = int(captcha_solve_before_time)
        if captcha_solve_before_time < 0:
            captcha_solve_before_time = 180
    except (ValueError, TypeError):
        captcha_solve_before_time = 180
    
    # log_level з settings
    log_level = settings.get("log_level", "INFO").upper()
    if log_level not in ["INFO", "DEBUG"]:
        log_level = "INFO"
    
    # max_purchase_retries з settings (кількість спроб покупки)
    max_purchase_retries = settings.get("max_purchase_retries", 3)
    try:
        max_purchase_retries = int(max_purchase_retries)
        if max_purchase_retries < 1:
            max_purchase_retries = 3
    except (ValueError, TypeError):
        max_purchase_retries = 3
    
    # Створюємо бота
    bot = PurchaseBot(
        email_address=email,
        password=password,
        product_id=product_id,
        check_interval=check_interval,
        start_time=start_time,
        captcha_api=captcha_api,
        captcha_solve_before_time=captcha_solve_before_time,
        log_level=log_level,
        max_purchase_retries=max_purchase_retries
    )
    
    # Налаштовуємо Telegram для відправки логів (якщо вказано)
    telegram_config = config.get("telegram")
    if telegram_config:
        bot.set_telegram_config(telegram_config)
    
    # Запускаємо бота
    try:
        success = bot.run()
        if success:
            print()
            print("[SUCCESS] Бот успішно завершив роботу!")
            # Логи вже відправлені в методі run() при завершенні
            sys.exit(0)
        else:
            print()
            print("[ERROR] Бот завершив роботу з помилкою!")
            # Відправляємо логи навіть при помилці
            if bot.send_logs_on_exit:
                bot.send_logs_to_telegram()
            sys.exit(1)
    except KeyboardInterrupt:
        print()
        print("[WARNING] Роботу бота перервано користувачем")
        bot.is_running = False
        # Відправляємо логи при перериванні
        if bot.send_logs_on_exit:
            bot.send_logs_to_telegram()
        sys.exit(1)
    except Exception as e:
        print()
        print(f"[ERROR] Критична помилка: {e}")
        import traceback
        traceback.print_exc()
        # Відправляємо логи при критичній помилці
        if bot.send_logs_on_exit:
            bot.send_logs_to_telegram()
        sys.exit(1)

if __name__ == "__main__":
    main()
