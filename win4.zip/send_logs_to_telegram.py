#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Скрипт для відправки логів в Telegram та очищення їх після відправки
"""

import json
import os
import sys
import glob
from datetime import datetime
import requests

def load_config(config_path="config.json"):
    """Завантажує конфігурацію з файлу"""
    if not os.path.exists(config_path):
        print(f"[ERROR] Файл конфігурації {config_path} не знайдено!")
        return None
    
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
        return config
    except Exception as e:
        print(f"[ERROR] Помилка читання конфігурації: {e}")
        return None

def send_file_to_telegram(bot_token, chat_id, file_path, caption=None):
    """
    Відправляє файл в Telegram
    
    Args:
        bot_token: Токен Telegram бота
        chat_id: ID чату (може бути числом або рядком)
        file_path: Шлях до файлу
        caption: Підпис до файлу
    
    Returns:
        True якщо успішно, False якщо помилка
    """
    url = f"https://api.telegram.org/bot{bot_token}/sendDocument"
    
    try:
        with open(file_path, 'rb') as file:
            files = {'document': file}
            data = {
                'chat_id': str(chat_id),
            }
            if caption:
                data['caption'] = caption
            
            response = requests.post(url, files=files, data=data, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                if result.get('ok'):
                    return True
                else:
                    print(f"[ERROR] Telegram API помилка: {result.get('description', 'Unknown error')}")
                    return False
            else:
                print(f"[ERROR] HTTP помилка: {response.status_code}")
                return False
    except Exception as e:
        print(f"[ERROR] Помилка відправки файлу {file_path}: {e}")
        return False

def send_message_to_telegram(bot_token, chat_id, message):
    """
    Відправляє текстове повідомлення в Telegram
    
    Args:
        bot_token: Токен Telegram бота
        chat_id: ID чату
        message: Текст повідомлення
    
    Returns:
        True якщо успішно, False якщо помилка
    """
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    
    try:
        data = {
            'chat_id': str(chat_id),
            'text': message,
            'parse_mode': 'HTML'
        }
        
        response = requests.post(url, json=data, timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            if result.get('ok'):
                return True
            else:
                print(f"[ERROR] Telegram API помилка: {result.get('description', 'Unknown error')}")
                return False
        else:
            print(f"[ERROR] HTTP помилка: {response.status_code}")
            return False
    except Exception as e:
        print(f"[ERROR] Помилка відправки повідомлення: {e}")
        return False

def find_log_files(directory="."):
    """
    Знаходить всі лог-файли та файли з відповідями сервера
    
    Returns:
        Список шляхів до файлів
    """
    log_files = []
    
    # Шукаємо .log файли
    log_files.extend(glob.glob(os.path.join(directory, "purchase_bot_*.log")))
    
    # Шукаємо JSON файли з відповідями
    log_files.extend(glob.glob(os.path.join(directory, "purchase_bot_*_server_responses.json")))
    
    # Сортуємо за часом модифікації (новіші спочатку)
    log_files.sort(key=os.path.getmtime, reverse=True)
    
    return log_files

def send_logs_to_telegram(log_files=None, config_path="config.json", telegram_config=None, auto_delete=True):
    """
    Відправляє логи в Telegram та очищає їх після відправки
    
    Args:
        log_files: Список файлів для відправки (якщо None, знаходить автоматично)
        config_path: Шлях до конфігураційного файлу (якщо telegram_config не вказано)
        telegram_config: Словник з налаштуваннями Telegram (пріоритет над config_path)
        auto_delete: Чи видаляти файли після успішної відправки
    
    Returns:
        True якщо успішно, False якщо помилка
    """
    # Отримуємо конфігурацію Telegram
    if telegram_config:
        # Використовуємо передану конфігурацію
        bot_token = telegram_config.get("bot_token")
        chat_id = telegram_config.get("chat_id")
    else:
        # Завантажуємо з файлу
        config = load_config(config_path)
        if not config:
            return False
        
        telegram_config = config.get("telegram", {})
        bot_token = telegram_config.get("bot_token")
        chat_id = telegram_config.get("chat_id")
    
    if not bot_token or not chat_id:
        print("[ERROR] Telegram налаштування не знайдено!")
        print("[INFO] Додайте в config.json:")
        print('  "telegram": {')
        print('    "bot_token": "YOUR_BOT_TOKEN",')
        print('    "chat_id": "YOUR_CHAT_ID"')
        print('  }')
        return False
    
    # Знаходимо файли якщо не вказано
    if log_files is None:
        log_files = find_log_files()
    
    if not log_files:
        print("[INFO] Лог-файли не знайдено")
        return True
    
    print(f"[INFO] Знайдено {len(log_files)} файлів для відправки")
    
    # Відправляємо повідомлення про початок
    start_message = f"📤 <b>Відправка логів</b>\n\nЗнайдено файлів: {len(log_files)}\nЧас: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    send_message_to_telegram(bot_token, chat_id, start_message)
    
    # Відправляємо кожен файл
    success_count = 0
    failed_files = []
    
    for file_path in log_files:
        file_name = os.path.basename(file_path)
        file_size = os.path.getsize(file_path)
        file_size_mb = file_size / (1024 * 1024)
        
        print(f"[INFO] Відправка: {file_name} ({file_size_mb:.2f} MB)")
        
        # Формуємо підпис
        caption = f"📄 {file_name}\nРозмір: {file_size_mb:.2f} MB"
        
        if send_file_to_telegram(bot_token, chat_id, file_path, caption):
            success_count += 1
            print(f"[OK] Файл {file_name} успішно відправлено")
            
            # Видаляємо файл після успішної відправки
            if auto_delete:
                try:
                    os.remove(file_path)
                    print(f"[OK] Файл {file_name} видалено")
                except Exception as e:
                    print(f"[WARNING] Не вдалося видалити {file_name}: {e}")
        else:
            failed_files.append(file_name)
            print(f"[ERROR] Не вдалося відправити {file_name}")
    
    # Відправляємо підсумок
    if success_count > 0:
        summary = f"✅ <b>Відправка завершена</b>\n\nУспішно відправлено: {success_count}/{len(log_files)}"
        if failed_files:
            summary += f"\n\n❌ Не вдалося відправити:\n" + "\n".join(failed_files)
        send_message_to_telegram(bot_token, chat_id, summary)
    
    return success_count == len(log_files)

def main():
    """Головна функція для запуску вручну"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Відправка логів в Telegram")
    parser.add_argument("--config", default="config.json", help="Шлях до конфігураційного файлу")
    parser.add_argument("--no-delete", action="store_true", help="Не видаляти файли після відправки")
    parser.add_argument("--files", nargs="+", help="Конкретні файли для відправки")
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("Відправка логів в Telegram")
    print("=" * 60)
    print()
    
    success = send_logs_to_telegram(
        log_files=args.files,
        config_path=args.config,
        telegram_config=None,  # Завантажується з config_path
        auto_delete=not args.no_delete
    )
    
    if success:
        print()
        print("[SUCCESS] Всі логи успішно відправлено!")
        sys.exit(0)
    else:
        print()
        print("[ERROR] Деякі логи не вдалося відправити")
        sys.exit(1)

if __name__ == "__main__":
    main()

